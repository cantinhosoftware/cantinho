import xbmcaddon

MainBase = 'aHR0cHM6Ly90aW55dXJsLmNvbS80YzNiMHgtbTNudXByMW5jMXA0bA=='.decode('base64')
addon = xbmcaddon.Addon('plugin.video.aceboxtv')